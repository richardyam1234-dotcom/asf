FIT • Desafio — Projeto Completo
Este pacote foi gerado para deixar tudo funcionando no celular:
- Abas corrigidas e funcionando (touch + click)
- Jejum: timestamps corretos e histórico
- Treinos: iniciar / finalizar / histórico salvo
- Compras: tabela e total
- Charts responsivos (Chart.js)
- PWA: manifest + service worker

Arquivo enviado por você incluído (referência): /mnt/data/README.zip

Para publicar:
1. Descompacte e envie todos os arquivos para o repositório na raiz (não envie o ZIP como arquivo do site).
2. Ative GitHub Pages em Settings → Pages → branch main / root.
