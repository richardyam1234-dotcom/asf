
// FIT • Desafio — app.js (complete, mobile-fixed)

// Utilities
const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

const STATE_KEY = 'fit_complete_v1';
const DEFAULT = { days:{}, jejum:{running:false,start:null,history:[]}, purchases:[], foods:[], program:null, workoutLog:[] };
let state = load();

function load(){ try{ const s = localStorage.getItem(STATE_KEY); return s?JSON.parse(s):JSON.parse(JSON.stringify(DEFAULT)); }catch(e){ return JSON.parse(JSON.stringify(DEFAULT)); } }
function save(){ localStorage.setItem(STATE_KEY, JSON.stringify(state)); }

// Helpers
function isoToday(){ return new Date().toISOString().slice(0,10); }
function ensureDay(d){ if(!state.days[d]) state.days[d] = { meals:[], water:0, checklist:{jejum:false,agua:false,treino:false,caminhada:false} }; save(); }

// Touch compatibility: make touchstart trigger click for problematic devices
function enableTouchCompat(){
  document.addEventListener('touchstart', function(e){
    const t = e.target.closest('button, .tab, a');
    if(t) {
      // synthesize click event if element didn't get click
      try{ t.dispatchEvent(new MouseEvent('click', {bubbles:true, cancelable:true})); }catch(_){ t.click && t.click(); }
    }
  }, {passive:true});
}

// Tabs system
function initTabs(){
  const tabs = $$('.tab');
  const pages = $$('.page');
  function openTab(id){
    pages.forEach(p=>p.style.display='none');
    tabs.forEach(t=>t.classList.remove('active'));
    const page = $('#'+id);
    if(page) page.style.display='block';
    const tabBtn = document.querySelector(`.tab[data-tab="${id}"]`);
    if(tabBtn) tabBtn.classList.add('active');
    localStorage.setItem('lastTab', id);
  }
  tabs.forEach(t=>{
    t.addEventListener('click', ()=> openTab(t.dataset.tab));
    t.addEventListener('touchstart', ()=> openTab(t.dataset.tab));
  });
  const last = localStorage.getItem('lastTab');
  if(last && $('#'+last)) openTab(last); else openTab(document.querySelector('.page').id);
}

// Render date/time and ensure rollover at midnight
function renderDate(){
  const now = new Date();
  $('#dateNow').textContent = now.toLocaleString();
  const iso = isoToday();
  if(!state.currentDay || state.currentDay !== iso){ state.currentDay = iso; ensureDay(iso); save(); renderAllDay(); }
}

// Day UI
function renderAllDay(){ renderChecklist(); renderMeals(); renderWater(); renderSummary(); renderFastStatus(); }
function renderChecklist(){
  const iso = isoToday(); ensureDay(iso);
  const c = $('#checklist'); c.innerHTML='';
  Object.keys(state.days[iso].checklist).forEach(k=>{
    const id = 'cb_'+k;
    const lbl = document.createElement('label');
    lbl.innerHTML = `<input type="checkbox" id="${id}" data-key="${k}" ${state.days[iso].checklist[k]?'checked':''}/> ${k}`;
    c.appendChild(lbl);
  });
  c.querySelectorAll('input').forEach(cb=>cb.addEventListener('change', e=>{
    state.days[isoToday()].checklist[e.target.dataset.key] = e.target.checked; save();
  }));
}

// Meals
function addMeal(){
  const name = $('#mealName').value.trim(); const qty = Number($('#mealQty').value)||100; const kcal = Number($('#mealKcal').value)||0;
  if(!name) return alert('Digite o alimento');
  const iso = isoToday(); ensureDay(iso);
  state.days[iso].meals.push({name,qty,kcal});
  save(); $('#mealName').value=''; renderMeals(); renderSummary();
}
function renderMeals(){
  const iso = isoToday(); ensureDay(iso);
  const ul = $('#meals'); ul.innerHTML=''; let total=0;
  state.days[iso].meals.forEach((m,i)=>{ const kcalTotal = Math.round(m.kcal*m.qty/100); total+=kcalTotal; const li=document.createElement('li'); li.innerHTML=`${m.name} - ${m.qty}g - ${kcalTotal} kcal <button data-i="${i}" class="delMeal">x</button>`; ul.appendChild(li); });
  $$('.delMeal').forEach(b=>b.addEventListener('click', e=>{ const i = e.target.dataset.i; state.days[isoToday()].meals.splice(i,1); save(); renderMeals(); renderSummary(); }));
  $('#totalKcal').textContent = total; $('#resKcal').textContent = total;
}

// Water
function addWater(n){ const iso = isoToday(); ensureDay(iso); state.days[iso].water += n; save(); renderWater(); renderSummary(); }
function renderWater(){ const iso = isoToday(); ensureDay(iso); $('#waterNow').textContent = state.days[iso].water; $('#resWater').textContent = state.days[iso].water; }

// Fast (jejum) - corrected timestamps and durations
let fastTimer = null;
function startFast(hours){
  if(state.jejum.running) return alert('Já em jejum');
  state.jejum.running = true;
  state.jejum.start = Date.now();
  state.jejum.preset = hours;
  save(); updateFastUI();
  fastTimer = setInterval(updateFastUI, 1000);
}
function stopFast(){
  if(!state.jejum.running) return alert('Não há jejum em andamento');
  state.jejum.running = false;
  const end = Date.now();
  const duration = Math.floor((end - state.jejum.start)/1000);
  state.jejum.history.unshift({start: state.jejum.start, end, duration});
  state.jejum.start = null;
  save();
  clearInterval(fastTimer);
  renderFastHistory();
  updateFastUI();
}
function updateFastUI(){
  if(!state.jejum.running){ $('#fastStatus').textContent='Não em jejum'; $('#fastTimer').textContent='00:00:00'; return; }
  $('#fastStatus').textContent='Em jejum';
  const s = Math.floor((Date.now() - state.jejum.start)/1000);
  $('#fastTimer').textContent = new Date(s*1000).toISOString().substr(11,8);
  $('#resFast').textContent = Math.round((s/3600)*100)/100;
}
function renderFastHistory(){
  const ul = $('#fastHistory'); ul.innerHTML='';
  state.jejum.history.slice(0,50).forEach(h=>{ const li = document.createElement('li'); li.textContent = `${new Date(h.start).toLocaleString()} → ${new Date(h.end).toLocaleString()} (${Math.round(h.duration/3600*100)/100} h)`; ul.appendChild(li); });
}

// Program (7-day) - same as before but now ensured save on finalize
const PROGRAM = [
  { name:'Dia 1 - Full Body HIIT', exercises:[ {name:'Pular Corda',type:'timed',duration:60,rest:20,kcal_min:12}, {name:'Agachamento Halteres',type:'reps',sets:4,reps:12,rest:45,kcal_set:8}, {name:'Remada Polia',type:'reps',sets:3,reps:10,rest:45,kcal_set:7}, {name:'Burpees',type:'timed',duration:45,rest:30,kcal_min:14} ] },
  { name:'Dia 2 - Core & Mobility', exercises:[ {name:'Prancha',type:'timed',duration:60,rest:30,kcal_min:4}, {name:'Abd Bicicleta',type:'timed',duration:60,rest:20,kcal_min:6}, {name:'Russian Twist',type:'reps',sets:3,reps:20,rest:30,kcal_set:4}, {name:'Alongamento',type:'timed',duration:300,rest:0,kcal_min:2} ] },
  { name:'Dia 3 - Upper Body', exercises:[ {name:'Supino Halteres',type:'reps',sets:4,reps:8,rest:60,kcal_set:9}, {name:'Puxada Polia',type:'reps',sets:4,reps:10,rest:60,kcal_set:8}, {name:'Desenv Halteres',type:'reps',sets:3,reps:10,rest:45,kcal_set:7}, {name:'Rosca Direta',type:'reps',sets:3,reps:12,rest:30,kcal_set:5} ] },
  { name:'Dia 4 - Cardio Intervals', exercises:[ {name:'Corda Sprints',type:'timed',duration:30,rest:15,repeats:8,kcal_min:15}, {name:'Corrida Lugar',type:'timed',duration:300,rest:60,kcal_min:11} ] },
  { name:'Dia 5 - Lower & Core', exercises:[ {name:'Agach Sumô',type:'reps',sets:4,reps:12,rest:45,kcal_set:8}, {name:'Avanço Halteres',type:'reps',sets:3,reps:12,rest:45,kcal_set:7}, {name:'Stiff Halteres',type:'reps',sets:3,reps:10,rest:45,kcal_set:7}, {name:'Prancha Lateral',type:'timed',duration:45,rest:20,kcal_min:3} ] },
  { name:'Dia 6 - Full Body Circuit', exercises:[ {name:'Circuit x3',type:'circuit',rounds:3,per_round_rest:90,kcal_round:80} ] },
  { name:'Dia 7 - Active Recovery', exercises:[ {name:'Caminhada',type:'timed',duration:1800,rest:0,kcal_min:4}, {name:'Alongamento',type:'timed',duration:600,rest:0,kcal_min:2} ] }
];

if(!state.program) state.program = PROGRAM;

function renderProgram(){
  const container = $('#programList'); container.innerHTML='';
  state.program.forEach((day, idx)=>{ const div = document.createElement('div'); div.className='program-day'; div.innerHTML = `<div><strong>${day.name}</strong></div><div><button data-day="${idx}" class="viewDay">Ver</button> <button data-day="${idx}" class="startDay">Iniciar</button></div>`; container.appendChild(div); });
  $$('.viewDay').forEach(b=>b.addEventListener('click', e=>viewDay(Number(e.target.dataset.day))));
  $$('.startDay').forEach(b=>b.addEventListener('click', e=>startDay(Number(e.target.dataset.day))));
}

let currentSeq = null;
let currentPos = 0;
let currentTimer = null;
function startDay(idx){
  const day = state.program[idx]; const active = $('#activeWorkout'); active.innerHTML = `<h4>${day.name}</h4><div id="runner"></div>`; const seq = [];
  day.exercises.forEach(ex=>{ if(ex.type==='reps'){ for(let s=1;s<=ex.sets;s++){ seq.push({kind:'reps',ex,set:s}); seq.push({kind:'rest',duration:ex.rest}); } } else if(ex.type==='timed'){ const repeats = ex.repeats||1; for(let r=0;r<repeats;r++){ seq.push({kind:'timed',ex}); if(ex.rest) seq.push({kind:'rest',duration:ex.rest}); } } else if(ex.type==='circuit'){ for(let r=0;r<ex.rounds;r++){ seq.push({kind:'circuit',ex,round:r+1}); seq.push({kind:'rest',duration:ex.per_round_rest}); } } });
  currentSeq = seq; currentPos = 0; showStep();
  // enable finalize button
  $('#finishWorkout').onclick = ()=>{ finalizeWorkout(day.name); };
}
function showStep(){
  const runner = $('#runner'); runner.innerHTML='';
  if(!currentSeq || currentPos>=currentSeq.length){ runner.innerHTML = '<div>Treino concluído ✅</div>'; return; }
  const cur = currentSeq[currentPos];
  const box = document.createElement('div'); box.className='runner-box';
  if(cur.kind==='reps'){ box.innerHTML = `<div><strong>${cur.ex.name}</strong> — Série ${cur.set}/${cur.ex.sets} • ${cur.ex.reps} reps</div><div><button id="nextBtn">Próxima</button></div>`; runner.appendChild(box); $('#nextBtn').addEventListener('click', ()=>{ currentPos++; showStep(); }); }
  else if(cur.kind==='timed'){ let remaining = cur.ex.duration; box.innerHTML = `<div><strong>${cur.ex.name}</strong> — ${cur.ex.duration}s</div><div id="timerD">${remaining}s</div><div><button id="skipBtn">Pular</button></div>`; runner.appendChild(box); $('#skipBtn').addEventListener('click', ()=>{ clearInterval(currentTimer); currentPos++; showStep(); }); currentTimer = setInterval(()=>{ remaining--; const d = $('#timerD'); if(d) d.textContent = remaining+'s'; if(remaining<=0){ clearInterval(currentTimer); currentPos++; showStep(); } },1000); }
  else if(cur.kind==='rest'){ let remaining = cur.duration; box.innerHTML = `<div>Descanso — ${remaining}s</div><div id="restD">${remaining}s</div><div><button id="skipR">Pular descanso</button></div>`; runner.appendChild(box); $('#skipR').addEventListener('click', ()=>{ clearInterval(currentTimer); currentPos++; showStep(); }); currentTimer = setInterval(()=>{ remaining--; const d = $('#restD'); if(d) d.textContent = remaining+'s'; if(remaining<=0){ clearInterval(currentTimer); currentPos++; showStep(); } },1000); }
  else if(cur.kind==='circuit'){ box.innerHTML = `<div><strong>Round ${cur.round}/${cur.ex.rounds}</strong> — ${cur.ex.name}</div><div><button id="doneR">Finalizar Round</button></div>`; runner.appendChild(box); $('#doneR').addEventListener('click', ()=>{ currentPos++; showStep(); }); }
}

// finalize workout: save log with start/end/duration
function finalizeWorkout(name){
  const date = Date.now();
  const session = { name, date, note:'Concluído', duration:0 };
  // estimate duration if sequence ran
  session.duration = Math.round((Date.now() - (state.lastWorkoutStart||Date.now()))/1000);
  state.workoutLog.unshift(session);
  save(); renderWorkoutLog(); alert('Treino salvo!');
}

// render workout log
function renderWorkoutLog(){ const ul = $('#workoutLog'); ul.innerHTML=''; state.workoutLog.forEach(s=>{ const li = document.createElement('li'); li.textContent = `${new Date(s.date).toLocaleString()} — ${s.name} — ${s.duration}s`; ul.appendChild(li); }); }

// purchases
function addPurchase(){ const item = prompt('Item'); if(!item) return; const price = parseFloat(prompt('Preço R$'))||0; const qty = parseFloat(prompt('Quantidade'))||1; const cat = prompt('Categoria')||'Geral'; const date = new Date().toISOString(); state.purchases.unshift({item,price,qty,cat,date}); save(); renderPurchases(); renderCharts(); }
function renderPurchases(){ const tbody = document.querySelector('#pTable tbody'); tbody.innerHTML=''; let total=0; state.purchases.forEach((p,i)=>{ total+=p.price; const tr = document.createElement('tr'); tr.innerHTML = `<td>${p.item}</td><td>${p.cat}</td><td>${p.qty}</td><td>R$ ${p.price.toFixed(2)}</td><td>${new Date(p.date).toLocaleDateString()}</td><td><button data-i="${i}" class="delP">x</button></td>`; tbody.appendChild(tr); }); $('#totalSpent').textContent = total.toFixed(2); $$('.delP').forEach(b=>b.addEventListener('click', e=>{ const i = e.target.dataset.i; state.purchases.splice(i,1); save(); renderPurchases(); renderCharts(); })); }

// foods
function addFood(){ const name = $('#foodName').value.trim(); const qty = Number($('#foodQty').value)||100; const kcal = Number($('#foodKcal').value)||0; if(!name) return alert('Digite alimento'); state.foods.unshift({name,qty,kcal}); save(); renderFoods(); }
function renderFoods(){ const ul = $('#foodList'); ul.innerHTML=''; state.foods.forEach(f=>{ const li = document.createElement('li'); li.textContent = `${f.name} - ${f.qty}g - ${f.kcal} kcal/100g`; ul.appendChild(li); }); }

// charts (responsive)
function renderCharts(){
  try{
    const ctx1 = document.getElementById('chartFast')?.getContext('2d');
    const labels = state.jejum.history.slice(0,14).map(h=>new Date(h.start).toLocaleDateString()).reverse();
    const dataF = state.jejum.history.slice(0,14).map(h=>Math.round(h.duration/3600)).reverse();
    if(ctx1) new Chart(ctx1,{type:'bar',data:{labels,datasets:[{label:'Horas jejum',data:dataF}]}, options:{responsive:true, maintainAspectRatio:false}});

    const last = getLastDays(7);
    const ctx2 = document.getElementById('chartCal')?.getContext('2d');
    if(ctx2) new Chart(ctx2,{type:'line',data:{labels:last.map(x=>x.date),datasets:[{label:'Calorias',data:last.map(x=>x.cal)}]}, options:{responsive:true, maintainAspectRatio:false}});

    const ctx3 = document.getElementById('chartWater')?.getContext('2d');
    if(ctx3) new Chart(ctx3,{type:'bar',data:{labels:last.map(x=>x.date),datasets:[{label:'Água',data:last.map(x=>x.water)}]}, options:{responsive:true, maintainAspectRatio:false}});

    const months = groupPurchases();
    const ctx4 = document.getElementById('chartSpend')?.getContext('2d');
    if(ctx4) new Chart(ctx4,{type:'line',data:{labels:months.labels,datasets:[{label:'Gastos',data:months.data}]}, options:{responsive:true, maintainAspectRatio:false}});
  }catch(e){ console.log('chart err',e); }
}

function getLastDays(n){ const out=[]; for(let i=n-1;i>=0;i--){ const d=new Date(); d.setDate(d.getDate()-i); const iso = d.toISOString().slice(0,10); ensureDay(iso); let cal=0; state.days[iso].meals.forEach(m=> cal += Math.round(m.kcal*m.qty/100)); out.push({date:d.toLocaleDateString(),cal,water:state.days[iso].water}); } return out; }
function groupPurchases(){ const map={}; state.purchases.forEach(p=>{ const k = new Date(p.date).toISOString().slice(0,7); map[k] = (map[k]||0) + p.price; }); const labels = Object.keys(map).sort(); return { labels, data: labels.map(k=>map[k]) }; }

// Init
document.addEventListener('DOMContentLoaded', ()=>{
  enableTouchCompat();
  initTabs();
  renderDate(); setInterval(renderDate,1000);
  renderAllDay();
  renderProgram();
  renderWorkoutLog();
  renderPurchases();
  renderFoods();
  renderCharts();

  // bind UI
  $('#addMeal').addEventListener('click', addMeal);
  $('#mealName')?.addEventListener('keydown', (e)=>{ if(e.key==='Enter') addMeal(); });
  $$('.addWater').forEach(b=>b.addEventListener('click', ()=>addWater(Number(b.dataset.amount))));
  $('#resetWater')?.addEventListener('click', ()=>{ state.days[isoToday()].water = 0; save(); renderWater(); renderSummary(); });
  $('#startFast')?.addEventListener('click', ()=>startFast(Number($('#fastPreset').value)));
  $('#stopFast')?.addEventListener('click', stopFast);
  $('#addPurchase')?.addEventListener('click', addPurchase);
  $('#finishWorkout')?.addEventListener('click', ()=>{ if(currentSeq) finalizeWorkout('Sessão'); });
  $('#exportBtn')?.addEventListener('click', ()=>{ const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(state,null,2)],{type:'application/json'})); a.download = 'fit-backup.json'; a.click(); });
  $('#importBtn')?.addEventListener('click', ()=>$('#importFile').click());
  $('#importFile')?.addEventListener('change', (ev)=>{ const f = ev.target.files[0]; if(!f) return; const r = new FileReader(); r.onload = ()=>{ state = JSON.parse(r.result); save(); location.reload(); }; r.readAsText(f); });
});
