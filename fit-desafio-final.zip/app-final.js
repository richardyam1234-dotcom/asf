
const KEY='fit_final_v1';
const defaultState={days:{},jejum:{running:false,start:null,history:[]},purchases:[],foods:[],routines:[]};
let state = load();
function load(){try{const s=localStorage.getItem(KEY);return s?JSON.parse(s):JSON.parse(JSON.stringify(defaultState))}catch(e){return JSON.parse(JSON.stringify(defaultState))}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function isoToday(){return new Date().toISOString().slice(0,10)}
function ensureDay(d){ if(!state.days[d]) state.days[d]={meals:[],water:0,checklist:{jejum:false,agua:false,treino:false,caminhada:false}} }

document.addEventListener('DOMContentLoaded',()=>{
  ensureDay(isoToday()); renderDate(); setInterval(renderDate,1000);
  bindTabs(); bindDayUI(); renderMeals(); renderWater(); renderChecklist(); renderFastUI(); renderExercises(); renderPurchases(); renderCharts();
  document.getElementById('exportBtn').addEventListener('click', ()=>download('fit_backup.json', JSON.stringify(state,null,2)));
  document.getElementById('importBtn').addEventListener('click', ()=>document.getElementById('importFile').click());
  document.getElementById('importFile').addEventListener('change', (e)=>{ const f=e.target.files[0]; const r=new FileReader(); r.onload=()=>{ state=JSON.parse(r.result); save(); location.reload(); }; r.readAsText(f); });
});

function renderDate(){ const now=new Date(); document.getElementById('dateNow').textContent = now.toLocaleString(); const today=isoToday(); if(!state.currentDay || state.currentDay!==today){ state.currentDay=today; ensureDay(today); save(); renderMeals(); renderWater(); renderChecklist(); renderSummary(); } }

function bindTabs(){ document.querySelectorAll('.tabs button').forEach(b=>b.addEventListener('click', ()=>{ document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active')); b.classList.add('active'); document.querySelectorAll('.tabview').forEach(t=>t.classList.remove('active')); document.getElementById(b.dataset.tab).classList.add('active'); if(b.dataset.tab==='relatorios') renderCharts(); })); }

// Meals
function bindDayUI(){
  document.getElementById('addMeal').addEventListener('click', ()=>{ const n=document.getElementById('mealName').value.trim(); const q=Number(document.getElementById('mealQty').value)||100; const k=Number(document.getElementById('mealKcal').value)||0; if(!n) return alert('Digite alimento'); const d=isoToday(); ensureDay(d); state.days[d].meals.push({name:n,qty:q,kcal:k}); save(); renderMeals(); renderSummary(); document.getElementById('mealName').value=''; });
  document.querySelectorAll('.addWater').forEach(b=>b.addEventListener('click', ()=>{ addWater(Number(b.dataset.amount)); }));
  document.getElementById('resetWater').addEventListener('click', ()=>{ state.days[isoToday()].water=0; save(); renderWater(); renderSummary(); });
  document.getElementById('startFast').addEventListener('click', ()=>{ startFast(Number(document.getElementById('fastPreset').value)); });
  document.getElementById('stopFast').addEventListener('click', ()=>{ stopFast(); });
  document.getElementById('addPurchase').addEventListener('click', ()=>{ addPurchase(); });
}

// render meals
function renderMeals(){ const ul=document.getElementById('meals'); ul.innerHTML=''; const d=isoToday(); ensureDay(d); let total=0; state.days[d].meals.forEach((m,i)=>{ const kcal=Math.round(m.kcal*m.qty/100); total+=kcal; const li=document.createElement('li'); li.innerHTML=`${m.name} - ${m.qty}g - ${kcal} kcal <button data-i="${i}" class="delMeal">x</button>`; ul.appendChild(li); }); document.querySelectorAll('.delMeal').forEach(b=>b.addEventListener('click', ()=>{ const i=b.dataset.i; state.days[isoToday()].meals.splice(i,1); save(); renderMeals(); renderSummary(); })); document.getElementById('totalKcal').textContent = total; document.getElementById('resKcal').textContent = total; }

// water
function addWater(n){ const d=isoToday(); ensureDay(d); state.days[d].water += n; save(); renderWater(); renderSummary(); }
function renderWater(){ const d=isoToday(); ensureDay(d); document.getElementById('waterNow').textContent = state.days[d].water; document.getElementById('resWater').textContent = state.days[d].water; }

// checklist
function renderChecklist(){ const d=isoToday(); ensureDay(d); const box=document.getElementById('checklist'); box.innerHTML=''; Object.keys(state.days[d].checklist).forEach(k=>{ const id='cb_'+k; const lbl=document.createElement('label'); lbl.innerHTML = `<input type="checkbox" id="${id}" data-key="${k}" ${state.days[d].checklist[k]?'checked':''}/> ${k}`; box.appendChild(lbl); }); box.querySelectorAll('input').forEach(cb=>cb.addEventListener('change', (e)=>{ const k=e.target.dataset.key; state.days[isoToday()].checklist[k]=e.target.checked; if(e.target.checked) state.points=(state.points||0)+5; save(); })); }

// summary
function renderSummary(){ const d=isoToday(); ensureDay(d); // kcal
  let kcal=0; state.days[d].meals.forEach(m=>kcal+=Math.round(m.kcal*m.qty/100)); document.getElementById('resKcal').textContent = kcal; document.getElementById('resWater').textContent = state.days[d].water; document.getElementById('resFast').textContent = Math.round(getFastHours()*100)/100; }

// fast (jejum)
let fastTimer=null;
function startFast(hours){ if(state.jejum.running) return alert('Já em jejum'); state.jejum.running=true; state.jejum.start=Date.now(); state.jejum.preset=hours; save(); updateFastUI(); fastTimer=setInterval(updateFastUI,1000); }
function stopFast(){ if(!state.jejum.running) return; state.jejum.running=false; const duration = Math.floor((Date.now()-state.jejum.start)/1000); state.jejum.history.unshift({start:state.jejum.start,duration}); state.jejum.start=null; save(); clearInterval(fastTimer); renderFastHistory(); updateFastUI(); }
function updateFastUI(){ if(!state.jejum.running){ document.getElementById('fastStatus').textContent='Não em jejum'; document.getElementById('fastTimer').textContent='00:00:00'; return; } document.getElementById('fastStatus').textContent='Em jejum'; const s=Math.floor((Date.now()-state.jejum.start)/1000); document.getElementById('fastTimer').textContent = new Date(s*1000).toISOString().substr(11,8); document.getElementById('resFast').textContent = Math.round(getFastHours()*100)/100; }
function getFastHours(){ if(!state.jejum.running) return 0; return (Date.now()-state.jejum.start)/(1000*3600); }
function renderFastHistory(){ const ul=document.getElementById('fastList'); ul.innerHTML=''; state.jejum.history.slice(0,50).forEach(h=>{ const li=document.createElement('li'); li.textContent = new Date(h.start).toLocaleString() + ' - ' + Math.round(h.duration/3600) + ' h'; ul.appendChild(li); }); }

// exercises (presets)
function renderExercises(){ const list=[{name:'Pular Corda',cal:8},{name:'Polia',cal:6},{name:'Agachamento',cal:7},{name:'Flexão',cal:6},{name:'Corrida',cal:10}]; const container=document.getElementById('exercises'); container.innerHTML=''; list.forEach((ex,idx)=>{ const div=document.createElement('div'); div.className='ex'; div.innerHTML = `<strong>${ex.name}</strong> — Est kcal/min: ${ex.cal} <button data-idx="${idx}" class="startEx">Iniciar</button>`; container.appendChild(div); }); document.querySelectorAll('.startEx').forEach(b=>b.addEventListener('click', (e)=>{ const idx=e.target.dataset.idx; startExercise(idx); })); window._exList=list; }

function startExercise(idx){ const ex=window._exList[idx]; const active=document.getElementById('active'); active.innerHTML = `<div><strong>${ex.name}</strong></div><div>Tempo: <span id="exTimer">00:00</span></div><button id="stopEx">Parar</button>`; let seconds=0; const t=setInterval(()=>{ seconds++; document.getElementById('exTimer').textContent = new Date(seconds*1000).toISOString().substr(14,5); },1000); document.getElementById('stopEx').addEventListener('click', ()=>{ clearInterval(t); const kcal = Math.round((seconds/60)*ex.cal); alert('Treino finalizado — kcal estimadas: '+kcal); state.routines.push({name:ex.name,sec:seconds,kcal}); save(); renderCharts(); active.innerHTML=''; }); }

// purchases
function addPurchase(){ const item=prompt('Item'); if(!item) return; const price=parseFloat(prompt('Preço R$'))||0; const qty=parseFloat(prompt('Quantidade'))||1; const cat=prompt('Categoria')||'Geral'; const date=new Date().toISOString(); state.purchases.unshift({item,price,qty,cat,date}); save(); renderPurchases(); renderCharts(); }
function renderPurchases(){ const tbody=document.querySelector('#pTable tbody'); tbody.innerHTML=''; let total=0; state.purchases.forEach((p,i)=>{ total += p.price; const tr=document.createElement('tr'); tr.innerHTML = `<td>${p.item}</td><td>${p.cat}</td><td>${p.qty}</td><td>R$ ${p.price.toFixed(2)}</td><td>${new Date(p.date).toLocaleDateString()}</td><td><button data-i="${i}" class="delP">x</button></td>`; tbody.appendChild(tr); }); document.getElementById('totalSpent').textContent = total.toFixed(2); document.querySelectorAll('.delP').forEach(b=>b.addEventListener('click', ()=>{ state.purchases.splice(b.dataset.i,1); save(); renderPurchases(); renderCharts(); })); }

// charts
function renderCharts(){
  try{
    const ctx1=document.getElementById('chartFast').getContext('2d');
    const labels=state.jejum.history.slice(0,14).map(h=>new Date(h.start).toLocaleDateString()).reverse();
    const dataF=state.jejum.history.slice(0,14).map(h=>Math.round(h.duration/3600)).reverse();
    new Chart(ctx1,{type:'bar',data:{labels,datasets:[{label:'Horas jejum',data:dataF}]}});
    const last=getLastDays(7);
    const ctx2=document.getElementById('chartCal').getContext('2d');
    new Chart(ctx2,{type:'line',data:{labels:last.map(x=>x.date),datasets:[{label:'Calorias',data:last.map(x=>x.cal)}]}});
    const ctx3=document.getElementById('chartWater').getContext('2d');
    new Chart(ctx3,{type:'bar',data:{labels:last.map(x=>x.date),datasets:[{label:'Água',data:last.map(x=>x.water)}]}});
    const months=groupPurchases();
    const ctx4=document.getElementById('chartSpend').getContext('2d');
    new Chart(ctx4,{type:'line',data:{labels:months.labels,datasets:[{label:'Gastos',data:months.data}]}});
  }catch(e){console.log('chart err',e)}
}

function getLastDays(n){ const out=[]; for(let i=n-1;i>=0;i--){ const d=new Date(); d.setDate(d.getDate()-i); const iso=d.toISOString().slice(0,10); ensureDay(iso); let cal=0; state.days[iso].meals.forEach(m=> cal+=Math.round(m.kcal*m.qty/100)); out.push({date:d.toLocaleDateString(),cal,water:state.days[iso].water}); } return out; }
function groupPurchases(){ const map={}; state.purchases.forEach(p=>{ const k=new Date(p.date).toISOString().slice(0,7); map[k]=(map[k]||0)+p.price; }); const labels=Object.keys(map).sort(); return {labels, data: labels.map(k=>map[k])}; }

// utilities
function download(filename, text){ const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([text],{type:'application/json'})); a.download=filename; a.click(); }
