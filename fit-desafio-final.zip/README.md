FIT • Desafio — Final (Black & Gold)
Arquivos prontos para upload no GitHub Pages. Substitua o repositório atual pelos arquivos deste ZIP.
- index.html
- styles.css (Black & Gold)
- app-final.js (todas funcionalidades locais: dia, refeições, água, jejum, treinos, compras, relatórios)
- manifest.json, sw.js (PWA)
Unzip and upload all files to your repo root (do NOT keep them zipped).
